<template>
    <div class="content-wrapper">
        <div class="error-message">
            Error: Incorrect Passphrase
        </div>
    </div>
</template>

<script>
export default {
    name: "SendStepIncorrectPassphrase"
}
</script>

<style scoped>
.error-message {
    font-size: 1.5em;
    font-weight: bold;
}
</style>
