<template>
    <div class="content-wrapper">
        <div>
            <p>
                Please wait a moment...
            </p>
        </div>
    </div>
</template>

<script>
export default {
    name: "SendStepWaitForReply",
}
</script>

<style scoped>
</style>
